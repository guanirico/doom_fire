var firepixels = []
const fireheigth = 8
const firewidth = 8

start()

function createtable() {
	var maxpixels = firewidth * fireheigth
	for ( var p = 0; p < maxpixels; p++ ){
		firepixels.push(0)
	}
}

function rendfire() {
	var table = ""

	for (var h = 0; h < fireheigth; h++) {
		table += "<tr>"
		for (var w = 0; w < firewidth; w++){
			table += "<td>"
			table += w+h
			table += "</td>"
		}
		table += "</tr>"
	}

	document.querySelector("#table").innerHTML = table
}

function start() {
	createtable()
	rendfire()
}